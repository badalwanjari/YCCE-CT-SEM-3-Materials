#include <stdio.h>
#include <conio.h>

int main(void)
{
    char ch;
    printf("Enter a Character: ");
    ch = getch();
    printf("Entered Character is = %c", ch);
    return 0;
}