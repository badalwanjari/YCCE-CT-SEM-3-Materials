#include <stdio.h>

int main(void)
{
    char ch;
    printf("Enter a Character: ");
    ch = getchar();
    printf("Entered Character is = %c", ch);
    return 0;
}