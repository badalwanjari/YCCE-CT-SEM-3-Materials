int compare(Node *list1, Node *list2) 
{
     // Code Here
     string h="",j="";
     while(list1!=NULL){
        h+=list1->c;
        list1=list1->next;
     }
     while(list2!=NULL){
        j+=list2->c;
        list2=list2->next;
     }
     if(h==j){return 0;}
     else if(h>j){return 1;}
     return -1;
}
